-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2018 at 04:52 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clubs`
--

-- --------------------------------------------------------

--
-- Table structure for table `final`
--

CREATE TABLE `final` (
  `w` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `role`) VALUES
('ghg', 'ASDF', 2),
('s', '123', 1),
('s', '123', 1),
('s', '123', 1),
('arpita', '123', 0),
('tri', '12345', 0),
('', '', 0),
('hiba', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `first` varchar(25) NOT NULL,
  `last` varchar(20) NOT NULL,
  `username` varchar(15) NOT NULL,
  `intrest` varchar(20) NOT NULL,
  `duration` varchar(20) NOT NULL,
  `days` int(5) NOT NULL,
  `DOB` varchar(10) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`first`, `last`, `username`, `intrest`, `duration`, `days`, `DOB`, `contact`, `gender`, `mail`) VALUES
('', '', '', '', '', 0, '', 0, '', ''),
('hiba', 'hiba', 'hiba', 'Karate', '1', 1, '2019-01-01', 9800788990, 'Female', 'ab@g'),
('Arpita', 'hjg', 'ghg', 'YOGA', '1', 1, '2018-12-01', 1478523692, 'Female', 'ghjhiuhijkjkj@bgfghf'),
('Triveni', 'Rangaswamy', 'tri', 'MMA', '1', 3, '1997-02-28', 9900254378, 'Female', 'trivenirg1997@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`mail`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
